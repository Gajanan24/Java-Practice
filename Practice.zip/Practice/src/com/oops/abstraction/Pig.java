package com.oops.abstraction;

public class Pig extends Animal {

	@Override
	public void sound() {
		System.out.println("It sounds like weee wee");
		
	}
	public static void main(String[] args) {
		
	
	Animal a=new Pig();
	a.colour();
	a.sound();
	//Pig p=new Pig();
	a.setName("Horse");
	System.out.println(a.getName());
	
	}
}
