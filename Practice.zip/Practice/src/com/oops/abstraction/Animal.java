package com.oops.abstraction;

public abstract class Animal {
	public abstract void sound();
	private String name;
	
	public void colour()
	{
		System.out.println("White");
	}
	public void setName(String name)
	{
		this.name=name;
	}
	public String getName()
	{
		return name;
		
	}
	
	 
	

}
