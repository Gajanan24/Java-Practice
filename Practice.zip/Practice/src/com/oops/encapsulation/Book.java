package com.oops.encapsulation;

public class Book {
	private String title;
	private String author;
	private double price;
	
	public Book(String title, String author, double price)
	{
		this.author=author;
		this.price=price;
		this.title=title;
	}
	
	public void setTitle(String title)
	{
		this.title=title;
	}
	public String getTitle()
	{
		return title;
	}
	
	public String getAuthor()
	{
		return author;
		
	}
	public void setAuthor(String author)
	{
		this.author=author;
	}
	
	public double getPrice()
	{
		return price;
		
	}
	public void setPrice(double price)
	{
		this.price=price;
	}
	
	public double getDiscountPrice()
	{
		return price * 0.9;
	}
	public String toString()
	{
		return title +" by "+ author + " $ Price: "+ price;
	}
	public static void main(String[] args) {
		Book b=new Book("Kosala", "B Nemade",  260);
		System.out.println( "Book "+ b);
		System.out.println("Discount price: $ " + b.getDiscountPrice());
		
		
		
		
	}

}
