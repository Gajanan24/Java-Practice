package com.oops.encapsulation;

public class demo {
   private String name;
   private double balance;
   private String phoneNo;
   
   public void setName(String name)
   {
	   this.name=name;
   }
   public String getName()
   {
	   return name;
   }
   
   public void setPhoneNo(String phoneNo)
   {
	   this.phoneNo=phoneNo;
   }
   public String getphoneNo()
   {
	return phoneNo;
	   
   }
   
   public double getBalance()
   {
	return balance;  
   }
   public void deposit(double amount )
   {
	   balance+=amount;
   }
   public void withdraw(double amount)
   {
	   balance-=amount;
   }
   public static void main(String[] args) {
	   demo d=new demo();
	   d.setName("Gajanan");
	   d.setPhoneNo("979845656");
	   d.deposit(2300);
	   System.out.println(d.getBalance());
}
   
}
