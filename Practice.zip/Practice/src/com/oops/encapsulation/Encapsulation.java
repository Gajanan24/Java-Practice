package com.oops.encapsulation;

public class Encapsulation {
	private int x;
	private int y;
	
	public void setX(int x)
	{
		this.x= x;
		
	}
	public int getX()
	{
		return x;
	}
	
	public int getY()
	{
		return y;
	}
	public void setY(int y)
	{
		this.y=y;
	}
	public static void main(String[] args) {
		Encapsulation e=new Encapsulation();
		e.setX(10);
		System.out.println(e.getX());
		
		e.setY(35);
		System.out.println(e.getY());
	}

}
