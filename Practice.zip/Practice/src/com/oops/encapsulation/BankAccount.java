package com.oops.encapsulation;

public class BankAccount {
	private String name;
	private double balance;
	
	public BankAccount(String name, double balance)
	{
		this.name=name;
		this.balance=balance;
	}
	
	public void setName(String n)
	{
		this.name=n;
	}
	public String getName()
	{
		return name;
	}
	
	
	public double getBalance()
	{
		return balance;
	}
	public void deposit(double amount )
	{
		balance += amount;
		
	}
	public void withdraw(double amount)
	{
		if(balance < amount)
		{
			System.out.println("Insufficient fundss");
		}
		else
		{
			balance-=amount;
			System.out.println("Accout balance: "+amount);
		}
	}
	public String toString() {
		return "name:S " +name + " balance: " + balance;
	}
	
	public static void main(String[] args) {
		BankAccount b=new BankAccount("Prasad", 500);
		
		System.out.println(b.getName());
		
		b.deposit(2000);
		b.withdraw(1000);
		
		String s=b.toString();
		System.out.println(s);
		
		
	}

}
