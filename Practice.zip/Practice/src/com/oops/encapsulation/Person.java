package com.oops.encapsulation;

public class Person {
	private String name;
	private int age;
	private String email;
	
	public Person(String name, int age, String email)
	{
		this.name=name;
		this.age=age;
		this.email=email;
	}
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name=name;
	}
    public String getEmail()
    {
    	return email;
    }
    public void setEmail(String email)
    {
    	this.email=email;
    }
    public int getAge()
    {
    	return age;
    }
    public void setAge()
    {
    	this.age=age;
    }
//    public String SendEmail()
//    {
//    	return 
//    }
//    
    
    public String toString()
    {
		return "Name " + name + "( "+ age +" )"+email;
    	
    }
    
    public static void main(String[] args) {
		Person p=new Person("Bhushan", 22, "pbhushan@gmail.com");
		System.out.println(p.toString());
		p.setName("Prasad");
		System.out.println(p.getName());
	}
    
    
    
    
    
}
