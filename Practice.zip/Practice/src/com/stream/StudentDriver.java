package com.stream;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;import java.util.stream.Collector;
import java.util.stream.Collectors;



public class StudentDriver {
	public static void main(String[] args) {
		
	
	List<String> names=new ArrayList<>();
	names.add("Gajanan");
	names.add("Akash");
	names.add("Prasad");
	names.add("Geeta");
	
	System.out.println(names);
	
	names.stream().map((s)-> s.toLowerCase()).forEach((s) -> System.out.println(s));
	
	System.out.println("Ends with a");
	names.stream().filter((s) -> s.endsWith("a")).forEach((s)  -> System.out.println(s));
	System.out.println("contain n");
	names.stream().filter((s) -> s.contains("n")).forEach((s)  -> System.out.println(s));
	
	Function<Integer, Integer> fact = (n) -> {
		int res = 1;
		while (n > 0) {
			res *= n;
			n--;
		} 
		return res;
	};
	System.out.println("fact of 3!=" + fact.apply(2));
	
	int t=9;
	int m=1;
	if(t >0) {
		t*=m;
		t--;
	}
	
	
	List<String> namesInUpperCaseList=names.stream().map((a) -> a.toUpperCase()).collect(Collectors.toList());
	
	
	System.out.println(namesInUpperCaseList);
	
	names.stream().filter((s)  -> s.indexOf('e') ==-1).forEach((s) -> System.out.println(s));
	
	
	
	
	
	
	
	
	}
}
