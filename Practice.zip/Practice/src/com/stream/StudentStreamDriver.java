package com.stream;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class StudentStreamDriver {
	
	public static void main(String[] args) {
		
	
	
	List<Student> studentList =new ArrayList<Student>();
	studentList.add(new Student(5,"Gajanan",2000.0));
	studentList.add(new Student(3,"Prasad", 700.0));
	studentList.add(new Student(2, "Mahitha", 1000.0));
	studentList.add(new Student(7,"Aish",2600.0));
	
	studentList.stream().map((s) -> s.getName()).forEach(System.out::println);
System.out.println("Student with fee greater than 1500: "+	studentList.stream().filter((s) -> s.getFee() >1500.0).count());
	}
}
