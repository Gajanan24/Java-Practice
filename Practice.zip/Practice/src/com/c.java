package com;

public class c {
	
	
	public c(){
		int a;
		String b = "";
	}
	public void methods() {
		int a = 10;
		int c = 20;
		
		int sum = a+c;
		System.out.println(sum);
		
	}
	

}
