package com;

public class ABC {
	
	int i;
	int j;
	
	
	
	
	public ABC() {
		j=1;
		
	}
	
	



	public ABC(int i) {
		
		this.i = i;
	}





	public static void main(String[] args) {
		
		
		
		 int [] array= {1,4,7,-6,-35,-9,-5};
		    int j=0;
		    
		    for(int i=0; i< array.length; i++) {
		    	
		    	if(array[i]< 1 ) {
		    		
		    		j++;
		    	}
		    	
		    }
		    System.out.println(j);
		    
		    ABC a=new ABC();
		    ABC b=new ABC();
		    System.out.println(a.equals(b));
		    
		    ABC a1=new ABC(25);
		    ABC a2=new ABC(25);
		    
		    System.out.println(a1.equals(a2));
		    
		
	}

}
