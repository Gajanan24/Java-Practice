package com;

public class Parent {
	int x=10;
	Parent(){
		System.out.println("Parent Constructor");
	}
	
	

}
