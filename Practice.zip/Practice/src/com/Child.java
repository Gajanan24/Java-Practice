package com;

public class Child  extends Parent {
	int x=20;
	
	Child(){
	      super();
		System.out.println("Child Constructor");
		
	}
	
	
	public static void main(String[] args) {
		
	
	Child child=new Child();
	    
       System.out.println(child.x);
       
       
	}
}
