package com;

public class A {
	 int age;
	 
	 public int m1()
	 {
		 //age=10;
		 return 10;
	 }
	 
	 public A(int i)
	 {
		System.out.println("Hello world"); 
	 }
	 public void m2()
	 {
		 System.out.println("Hi");
	 }
	
	public static void main(String[] args) {
		
	
		//Integer my=10;
		//System.out.println(my);
		A a=new A(0);
		System.out.println(a.m1());
		
		B c = new B();
	}

}
