package com.collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EmployeeDriver {
	
public static void main(String[] args) {
	
     
	
	List<Employee> emp=new ArrayList<>();
	emp.add(new Employee(6,"Vinayak",20000.0));
	emp.add(new Employee(2,"Gajanan",20000.0));
	emp.add(new Employee(7,"Sairaj",20000.0));
	
	
	for(Employee e:emp) {
		System.out.println(e);
	}
	System.out.println("After sorting");
	Collections.sort(emp);
	for(Employee e:emp) {
		System.out.println(e);
	}
	Map<Integer, Employee> employeeMap=new HashMap<>();
	
	for(Employee e :emp) {
		employeeMap.put(e.getId(), e);
	}
	System.out.println(employeeMap);
	
	System.out.println("Employee having id 2:"+employeeMap.get(2));
	
	
	
}
}
