package com.collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class StudentDriver {
	public static void main(String[] args) {
		Student student =new Student();
		
		//Array
		Student students[]=new Student[3];
		students[0]=new Student(1,"A",100.0);
		students[1]=new Student(2,"B",200.0);
		students[2]=new Student(3,"C",300.0);
		
		for(Student std:students) {
			System.out.println(std);
		}
		
		//List 
		
		List<Student> studentList=new ArrayList<>();
		studentList.add(new Student(5,"D",400.0));
		studentList.add(new Student(6,"E",500.0));
		studentList.add(new Student(7,"F",600.0));
		
		for(Student std:studentList) {
			System.out.println(std);
			
		}
		Collections.sort(studentList);;
		
		
		
		
		
		
		
	}

}
