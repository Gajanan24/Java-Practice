package com;

public class B {
	String dog="Jinger ";
 public String  dog() {
	 return this.dog;
 }
 String breeds ="this" ;
 
 public String breed( String breeds) {
	 return breeds;
 }
public static void main(String []args) {
  c t = new c();
  
	
		
		
}

}
