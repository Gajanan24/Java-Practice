package com.collectionSet;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class StudentDriver {
	public static void main(String[] args) {
		
		Set<Student> students=new HashSet<>();
		
		students.add(new Student(5,"AB",400.0));
		students.add(new Student(5,"AB",400.0));
		students.add(new Student(3,"CD",300.0));
		
		for(Student stu:students) {
			System.out.println(stu.name.hashCode());
			System.out.println(stu);
		}
		
		Student st=new Student(3,"CD",300.0);
		
		System.out.println(st.name.hashCode());
		
		
	}

}
