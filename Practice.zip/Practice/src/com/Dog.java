package com;

public class Dog {
	String breed;
	int age;
	
	public Dog(String br, int a) {
		this.age=a;
		this.breed=br;
		
	}
	public void bark()
	{
		System.out.println("hiii");
	}
	public static void main(String[] args) {
		Dog myDog=new Dog("ABC",14);
		myDog.bark();
		System.out.println(myDog.age);
		System.out.println(myDog.breed);
	}

}
