package com;

public class Practice {
	    
	int x=11;
		
		public void fly(int i)
		{
			System.out.println(x-i+ " ");
		}
		public static void main(String[] args) {
			new Practice().fly(7);
		}
	

	
	
	
}

