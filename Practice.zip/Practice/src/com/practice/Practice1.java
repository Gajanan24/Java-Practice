package com.practice;

public class Practice1 {
	public static void main(String[] args) {
//		int[]  x = {120, 200, 016};
////        for(int i = 0; i < x.length; i++){
////                 System.out.print(x[i] );
////                 
////        }
//        System.out.println(x.length);
		
		int i;
        for(i = 1; i < 6; i++){ 
            if(i > 3) continue;
        }
        System.out.println(i);
	}

}
