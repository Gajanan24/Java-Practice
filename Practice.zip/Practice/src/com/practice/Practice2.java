package com.practice;

public class Practice2 {
	   void  m1(int age)
	  {
		  if(age>18)
		  {
			  System.out.println("You are eligible for Voting");
		  }
		  else
		  {
			  System.out.println("Sorry");
		  }
	  }
	   public static void main(String[] args) {
	     Practice2 p= new Practice2();
	     p.m1(17);
	}
}
