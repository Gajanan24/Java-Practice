package com.practice;

public class Square {
	int side=10;
	
	public int getArea()
	{
		return side*side;
	}
	//public int getCircum
	
	public static void main(String[] args) {
		Square sq=new Square();
		System.out.println(sq.getArea());
	}

}
