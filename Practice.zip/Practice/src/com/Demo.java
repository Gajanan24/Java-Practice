package com;

public class Demo {
	public static void main(String[] args) {
//		Integer myInt=10;
//		String my=myInt.toString();
//		System.out.println(my);

		Integer myInt = 100;
	    String my = myInt.toString();
	    System.out.println(my.length());
	}

}
