package co.lambda;
@FunctionalInterface
public interface Animal {
	void sound();

}
