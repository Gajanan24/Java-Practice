package co.lambda;

import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

public class Cat {
	public static void main(String[] args) {
		Animal a = () -> System.out.println("Meow");
			
			a.sound();
		
	//Built in Functional Interfaces
	//Supplier 
	
	Supplier<String> CompanyName=() ->{
		return "capgemini";
	};
	System.out.println(CompanyName.get());
	
	Supplier<Integer> id =() -> {
		return 10;
	};
	System.out.println(id.get());
	
	Supplier<Double> val=() ->{
		return 10.0;
	};
	System.out.println(val.get());
	Supplier<Integer> intValue=() -> {
		return 127;
		
	};
	System.out.println(intValue.get());
	
	//Consumer
	
	Consumer<String> strConsumer = (s) -> System.out.println(s);
	strConsumer.accept("hello ");
	
	//function
	//Function
    Function<String,Integer> findLength = (s)->s.length();
	System.out.println("Length of 'gajanan' = "+findLength.apply("gajanan"));
	}
}
