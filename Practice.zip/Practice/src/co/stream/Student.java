package co.stream;

import java.util.ArrayList;
import java.util.List;

public class Student {
	   
	   Integer id;
	   String name;
	   Double fees;
	   
	   
	   
	   
	public Student(Integer id, String name, Double fees) {
		super();
		this.id = id;
		this.name = name;
		this.fees = fees;
	}




	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getFees() {
		return fees;
	}

	public void setFees(Double fees) {
		this.fees = fees;
	}




	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", fees=" + fees + "]";
	}
	


	


}
