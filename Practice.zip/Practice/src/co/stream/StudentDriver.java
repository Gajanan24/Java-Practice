package co.stream;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class StudentDriver {
	public static void main(String[] args) {
		List<Student> studentList = new ArrayList<>();
		studentList.add(new Student(10,"Gajanan", 1000.0));
		studentList.add(new Student(12,"Ravi",650.0));
		studentList.add(new Student(13,"Ani",800.0));
		studentList.add(new Student(12,"Bhush",300.0));
		
		System.out.println(studentList);
		studentList.stream().map((std)->std.getName()).forEach(System.out::println);;
		List<String> stdNameList=studentList.stream().
				map((std)->std.getName()).
				collect(Collectors.toList());
		System.out.println(stdNameList);
	
		
		studentList.stream().map((std)->std.getId()).forEach(System.out::println);
		
	    List<Integer> stdId=studentList.stream().map((s)-> s.getId()).collect(Collectors.toList());
		System.out.println(stdId);
		
		List<Student> stdFeeHikeList= studentList.stream().map((s)-> {
			Double fee=s.getFees()*1.1;
			s.setFees(fee);
			return s;
		}).collect(Collectors.toList());
		System.out.println(stdFeeHikeList);
		
       	List<Student> stdFees600= studentList.stream().filter((s)-> s.getFees()>600.0).collect(Collectors.toList());
		System.out.println(stdFees600);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
