package co.stream;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class Practice {
	
	public static void main(String[] args) {
		
	
	List<Integer> nums= Arrays.asList(5,9,3,6,3);
  Stream<Integer> data= nums.stream();
  
  nums.forEach(n -> System.out.println(n));
  System.out.println("hey");
   
   for(Integer i: nums) {
	   System.out.println(i);
	   
   }
   
	}
}
