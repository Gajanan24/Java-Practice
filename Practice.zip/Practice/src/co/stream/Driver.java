package co.stream;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class Driver {
	public static void main(String[] args) {
		
		List<String> names=new ArrayList<>();
		names.add("Gajanan");
		names.add("Akash");
		names.add("Aarti");
		names.add("Sayali");
		
		names.stream().map((s)-> s.toUpperCase()).forEach((s) -> System.out.println(s));
	List<String> newLCList=	names.stream().map((s)->s.toLowerCase()).collect(Collectors.toList());
	System.out.println(newLCList);
	
	}
}
