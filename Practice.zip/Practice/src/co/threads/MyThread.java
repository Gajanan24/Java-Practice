package co.threads;

public class MyThread  {
	public static void printNo()
	{
		for(int i=1; i<=10; i++) {
			System.out.println(i);
		}
	}
	public static void printAlpha() {
		for(char c='A'; c<='J'; c++) {
			System.out.println(c);
			
		}
	}
	
	public static void main(String[] args) {
		Thread t1=new Thread(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				printNo();
				
			}
		});
		Thread t2=new Thread(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				printAlpha();
				
			}
		});
		t1.start();
		t2.start();

}
}