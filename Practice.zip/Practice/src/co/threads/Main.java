package co.threads;

public class Main {
	public void printNo()
	{
		for(int i=1; i<=10; i++) {
			System.out.println(i);
		}
	}
	public void printAlpha() {
		for(char c='A'; c<='J'; c++) {
			System.out.println(c);
			
		}
	}
	public static void main(String[] args) {
		Main main=new Main();
		main.printNo();
		main.printAlpha();
	}

}
