package com.string;

import java.util.Arrays;

public class Demo3 {
	public static void m2(String s) {
	    char[] array = s.toCharArray();
	    for (int i = 0; i < array.length - 1; i++) {
	        for (int j = i + 1; j < array.length; j++) {
	            if (Character.toLowerCase(array[i]) > Character.toLowerCase(array[j])) {
	                char temp = array[i];
	                array[i] = array[j];
	                array[j] = temp;
	            }
	        }
	    }
	    System.out.println(Arrays.toString(array));
	}

	
	public static void sortAlphabetically(String str) {
	    char[] charArray = str.toCharArray();
	    
	    Arrays.sort(charArray);
	    System.out.println(String.valueOf(charArray));
	}


	
	
	
	public static void m1(String s,  char c) {
		int count=0;
		for(int i=0; i<s.length(); i++) {
			
			if(s.charAt(i)==c) {
				count++;
			}
			
		}
		System.out.println(count);
		
		
	}
	public static void main(String[] args) {
		m1("Gajanan", 'a');
		sortAlphabetically("Ggqajbaeghtjthjtyjrtyjtryjrytjananan");
		m2("Gajanan");
	}
	
	

}
