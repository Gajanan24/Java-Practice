package com.string;

public class Demo5 {
        // to find duplicate words in given String
	 public static void m1(String s) {
		String [] words= s.split(" ");
		int maxCount=0;
		String word="";
		
		for(int i=0; i< words.length; i++) {
			
			int count=1;
			if(words[i]=="0") {
				continue;
			}
			for(int j=i+1; j< words.length; j++) {
				if(words[i].equals(words[j])) {
					count++;
					words[j]="0";
				}
			}
			if(count> maxCount) {
				maxCount=count;
				 word=words[i];
				
			}
		}
		System.out.println("Repeated word: "+ word );
		
	 }
	 public static void main(String[] args) {
		m1("This is what i got what i got what");
	}
}
