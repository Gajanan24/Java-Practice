package com.string;

import java.util.Arrays;

public class MethodTestString {
	public static void main(String[] args) {
		String s = "Hi how are you?";
		System.out.println(s.replaceAll("\\s+", ""));
		String[] array = s.split("\\s+");
		System.out.println(Arrays.toString(array));
		for (String j : array) {
			System.out.println(j);
		}
		String s1="I am fine";
		System.out.println(s.concat(s1));

	}
}
