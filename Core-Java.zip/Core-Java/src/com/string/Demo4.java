package com.string;

public class Demo4 {
	
	//to find duplicate char in given String
	public static void m1(String s) {
   char [] array=s.toCharArray();
   int count;
            for(int i=0; i< array.length; i++) {
            	count=1;
            	
            	if(array[i]=='\0') {
            		continue;
            	}
            	for(int j=i+1; j<array.length; j++) {
            		if(array[i]==array[j]) {
            			count++;
            			array[j]='\0';
            		}
            	}
            	if(count>0) {
            		System.out.println(array[i] + " " + count);

            	}
            }
   
	}
	public static void main(String[] args) {
		m1("Gajanan");
		System.out.println("Gajanan");
	}

}
