package com.string;

public class Demo7 {
	
	//to find duplicate elements in string
	public static void m1(String s) {
	   char [] array=s.toCharArray();
	   
	   for(int i=0; i< array.length; i++) {
		   int count=1;
		   
		   if(array[i]=='\0') {
			   continue;
		   }
		   
		   for(int j=i+1; j<array.length; j++) {
			   if(array[i]==array[j]) {
				   count++;
				   array[j]='\0';
			   }
		   }
		   if(count> 0) {
			   System.out.println(array[i] + " " + count);
		   }
		   
	   }
	}
	public static void main(String[] args) {
		m1("Sayaliaa");
		
	}

}
