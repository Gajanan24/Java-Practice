package com.string;

public class Demo2 {
	public static char findSecondMostFrequentChar(String str) {
        int[] freq = new int[256]; // array to store frequency of each character
        
        // calculate frequency of each character
        for (int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);
            freq[c]++;
        }
        
        // find the character with second highest frequency
        int max1 = 0, max2 = 0;
        char result = '\0';
        for (int i = 0; i < freq.length; i++) {
            if (freq[i] > freq[max1]) {
                max2 = max1;
                max1 = i;
            } else if (freq[i] > freq[max2] && freq[i] != freq[max1]) {
                max2 = i;
            }
        }
        
        result = (char) max2;
        return result;
    }
    
    public static void main(String[] args) {
        String str = "Gajaaj";
        char c = findSecondMostFrequentChar(str);
        System.out.println("The second most frequent character in the string is: " + c);
    }
}
