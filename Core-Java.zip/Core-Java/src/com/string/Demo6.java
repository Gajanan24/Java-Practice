package com.string;

public class Demo6 {
	
	public static void m1(String s) {
	
		 
	String []array = s.split(" ");
	String smallest=array[0];
	String largest=array[0];
	  for(int i=0; i<array.length; i++) {
		   if(array[i].length() < smallest.length()) {
			   smallest=array[i];
		   }
		   if(array[i].length()> largest.length()) {
			   largest=array[i];
		   }
	  }
	  System.out.println("Smallest: "+ smallest);
	  System.out.println("Smallest: "+ largest);
	  
		
	}
	public static void main(String[] args) {
		m1("Gajanan Shinde is my brother");
	}

}
