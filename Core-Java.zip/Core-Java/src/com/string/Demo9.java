package com.string;

import java.util.HashSet;
import java.util.Set;

public class Demo9 {
	
	
	public static void m1(String s) {
		Set set=new HashSet();
		
		
		
		for(int i=0; i<s.length(); i++) {
			int count=1;
			Character cu=s.charAt(i);
			
			if(set.contains(cu)) {
				continue;
			}
			for(int j=i+1; j< s.length(); j++) {
				
				if(s.charAt(i)==s.charAt(j)) {
					count++;
					set.add(cu);
					
				}
				
				
			}
			if(count> 0) {
				System.out.println(s.charAt(i) +" " + count );
			}
			
		}
	}
	
	
	
	
	public static void main(String[] args) {
		String s1="HelloHe";
		String s2="Morning";
		
		String s3=s1+s2;
		
		//System.out.println(s3.substring(5, s3.length()));
		m1(s1);
	}

}
