package com.string;

public class Demo8 {
	
	//to print count of vowels in given string
	public static void m1(String s) {
		int count=0;
		for(int i=0; i< s.length(); i++) {
			if(s.charAt(i)=='!' || s.charAt(i)==',' || s.charAt(i)==';') {
				  count++;
			}
			
		}
		System.out.println(count + " Count");
	}
	
	//to reverse a string
	public static void m2(String s) {
		String string="";
		for(int i=s.length()-1; i>=0; i--) {
			string=string+s.charAt(i);
			
		}
		System.out.println(string);
	}
	
	public static void m3(String s) {
	   String [] array=s.split(" ");
	   String string="";
	    for(int i=array.length-1; i>=0; i--) {
	    	string=string+" "+array[i];
	    	
	    }
	    System.out.println(string);
	}
	public static void main(String[] args) {
		String s="Hi!!, I am; gajanan,";
		String s2="Good morning";
		m3(s2);
		m1(s);
		m2(s);
	}

}
