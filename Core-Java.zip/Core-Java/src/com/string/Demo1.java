package com.string;

import java.util.Arrays;

public class Demo1 {
	
	
	public static void m1(String s) {
		int  vCount=0;
		
		for(int i=0; i<s.length(); i++) {
			if(s.charAt(i) == 'a'  ||s.charAt(i)== 'e'|| s.charAt(i)== 'i' || s.charAt(i)=='o' ||s.charAt(i)== 'u' ) {
				vCount++;
			}
		    
		}
		System.out.println("Vowel count "+vCount);
	}
	
	public static void main(String[] args) {
		
	m1("This is simple sentence");
	
	int [] array= {2,435,76,4,-7,3};
	Arrays.sort(array);
	for(int i: array) {
		System.out.println(i);
	}
	
	
    }
} 
