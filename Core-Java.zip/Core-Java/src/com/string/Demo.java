package com.string;

import java.util.Arrays;

public class Demo {
	
	String s2="Gajana hi i am gajanan";
	public static void check(String string) {
		
		String [] array=string.split(" ");
		String largest=array[0];
		String smallest=array[0];
		for(int i=0; i< array.length; i++) {
			if(array[i].length() > largest.length()) {
				largest=array[i];
			}
			if(array[i].length() < smallest.length()) {
				smallest=array[i];
			}
			
		}
		System.out.println("smallest String: " + smallest);
		System.out.println("largest String: " + largest);
	}
	public static void main(String[] args) {
	System.out.println();	check("Gajana hi i am gajanan");
	String s3="Shinden";
	char [] array=s3.toCharArray();
	
	Arrays.sort(array);
	String sortedStr = new String(array);
	System.out.println(sortedStr);
	
//palindrom	
	String s="GaaG shinde";
	boolean check=true;
	for(int i=0; i<s.length()/2; i++) {
		if(s.charAt(i)!=s.charAt(s.length()-1-i)) {
			check=false;
			break;
		}
	}
	System.out.println(check);
	String oldString="shinde";
	String newString="kande";
			
	System.out.println(s.replace(oldString, newString));
	}
	
	
	
}
