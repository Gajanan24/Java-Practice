package com.stream;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import java.util.stream.*;

public class Demo {

	public static void main(String[] args) {
		List<Integer> list = new ArrayList();
		list.add(3);
		list.add(34);
		list.add(4);
		list.add(29);
//		 list.forEach(n -> System.out.println(n));
        Stream<Integer> st1 = list.stream();
        Stream<Integer> st2 = st1.filter(n -> n % 2 == 0);
        Stream<Integer> st3 = st2.map(n -> n * 2);
        
        
        st3.forEach(n -> System.out.println(n));
        String string="Gajanan";
        Collections.sort(list);
     
       
        
        
	}

}
