package com.linearSearch;

public class Demo {
     
	 
	 public static void  linearSearch(int [] array, int key) {
		 boolean found=false;
		 for(int i=0; i< array.length; i++) {
			
			 if(array[i] ==key) {
				System.out.println("Key is found at index position: " + i);
				found=true;
			 }
			
		 }
		 if(!found) {
		 System.out.println("No key found");
		 } 
		 
	 }
	 
	 public static void main(String[] args) {
		 int [] array= {1,2,4,6,8};
		linearSearch(array, 0);
	}
	
	 
}
