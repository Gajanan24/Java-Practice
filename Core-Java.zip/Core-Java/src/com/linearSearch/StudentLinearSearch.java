package com.linearSearch;

import java.util.ArrayList;
import java.util.List;

public class StudentLinearSearch {

	static List<StudentData> stdList = new ArrayList<>();

	public static StudentData linearSearch(Integer id) {

		boolean found = false;
		for (StudentData std : stdList) {
			if (std.getId() == id) {
				found = true;
				return std;
			}
		}
		if (!found) {
			System.out.println("No student found with id: " + id);
			;
		}
		return null;

	}

	public static void main(String[] args) {
		stdList.add(new StudentData(12, "Kiran"));
		stdList.add(new StudentData(1, "Navin"));
		stdList.add(new StudentData(3, "Kumar"));

		System.out.println(linearSearch(87));

	}

}
