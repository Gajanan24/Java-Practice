package com.java.array;

import java.util.Arrays;

public class Demo1 {
	
	//to copy array to new array
	   public static void m3(int [] array) {
		  
		   System.out.println(Arrays.toString(array));
		   int first = 0;
		   array[0]=first;
		   for(int i=0; i< array.length; i++) {
			   array[i+1]=array[i];
			  
			  array[i]=first;
			  
			   
		   }
		   System.out.println(Arrays.toString(array));
		   
		  
	   }
	
	//to find frequnecy of each element in array	
	public static void m2(int [] array) {
		for(int i=0; i< array.length; i++) {
			int count=1;
			
			if(array[i]==0) {
				continue;
			}
			for(int j=1+i; j<array.length; j++) {
				
				if(array[i]==array[j]) {
					count++;
					array[j]=0;
				}
				
			}
			if(count>0) {
				System.out.println(array[i] + " : " +count + " count");
			}
			
			
		}
	}
	
	//to copy array to new array
   public static void m1(int [] array) {
	   int [] array1=new int[array.length];
	   int j=0;
	   for(int i=0; i< array.length; i++) {
		   array1[i]=array[i];
		   
		   
	   }
	   System.out.println(Arrays.toString(array));
	   
	   System.out.println(Arrays.toString(array1));
   }
   
   
   public static void main(String[] args) {
	   int [] array= {6,4,6,6,9,6,9};
	   
	   for(int i=0; i< array.length; i++) {
		   
		   System.out.println(array[i]);
		   if(array[i]==9) {
			   break;
		   }
	   }
	   
	   
	   int [] arr1= {2,4,6};
	m1(array);
	m2(array);
	m4(arr1);
	
}
   public static void m4(int [] array) {
	   int j=array.length-1;
	   int temp=0;
	   for(int i=0; i< array.length/2; i++) {
		  temp=array[i];
		   array[i]=array[j];
		   array[j]=temp;
		   j--;
	   }
	   
	   for(int i: array) {
		   System.out.println(i +" reversed array");
	   }
   }
}
