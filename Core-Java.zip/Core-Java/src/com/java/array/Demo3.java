package com.java.array;

public class Demo3 {
	//to find smallest and largest number in an array
	public static void m1(int [] array) {
		
		int smallest=array[0];
		int largest=array[0];
		
		for(int i=0; i< array.length; i++) {
			if(array[i]< smallest) {
				smallest=array[i];
			}
			if(array[0]> largest) {
				largest=array[i];
			}
		}
		System.out.println("Smallest: " + smallest);
		System.out.println("largest: " + largest);
		
		
	}
	
	public static void main(String[] args) {
		int [] arr= {14,7,9,4,7};
		m1(arr);
	}
		

}
