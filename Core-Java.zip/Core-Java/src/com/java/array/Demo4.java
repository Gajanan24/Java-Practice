package com.java.array;

import java.util.Arrays;

public class Demo4 {
	
	//to find second largest element from array by sorting
  public static void m1(int [] array) {
	  int temp;
	  for(int i=0; i<array.length; i++) {
		  
		  for(int j=i+1; j< array.length; j++) {
			  
			  if(array[i] > array[j]) {
				  temp=array[j];
				  array[j]=array[i];
				  array[i]=temp;
			  }
		  }
		  
		  
	  }
	  for(int num: array) {
	  System.out.println(num);
	  
  }
	  System.out.println("Second largest: " + array[ array.length-2]);

	  
  }
  public static void main(String[] args) {
	  int []array= {2,5,3,7,9};
	m1(array);
}
}
