package com.java.array;

import java.util.Arrays;

public class Demo5 {
	
	public static int removeDuplicates(int[] arr) {
	    int j = 0;
	    
	    int n = arr.length;
	    if (n == 0 || n == 1) {
	        return n;
	    }
	    Arrays.sort(arr);
	    for (int i = 0; i < arr.length - 1; i++) {
	        if (arr[i] != arr[i + 1]) {
	            arr[j++] = arr[i];
	        }
	    }
	    arr[j++] = arr[arr.length - 1];

	    return j;
	}

	public static void main(String[] args) {
	    int [] array= {1,4,6,8,6,4};
	    int j = removeDuplicates(array);
	    for (int i = 0; i < j; i++) {
	        System.out.println(array[i] + " ");
	    }
	}


}
