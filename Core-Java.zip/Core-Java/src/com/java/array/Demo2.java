package com.java.array;

public class Demo2 {
	//sort by ascending order
	public static void m3(int [] array) {
		for(int i=0; i< array.length; i++) {
			int temp=0;
			for(int j=i+1; j<array.length; j++) {
				
				if(array[i]>array[j]) {
					temp=array[i];
					array[i]=array[j];
					array[j]=temp;
					
				}
			}
		}
		System.out.println("Elemenys of ascending order");
		for(int j=0; j< array.length; j++) {
			System.out.println(array[j]);
		}
	}
	
	public static void m2(int [] array) {
		for(int i=0; i< array.length; i++) {
			if(i%2==0) {
			System.out.println("even index"+array[i]);
			}
		}
	}
	
	public static void m1(int [] array) {
		for(int i=array.length-1; i>=0; i--) {
			System.out.println(array[i]);
		}
	}
	public static void main(String[] args) {
		int [] arr= {1,7,4,9,6};
		
		m1(arr);
		m2(arr);
		m3(arr);
	}

}
