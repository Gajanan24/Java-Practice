package com.java.array;

import java.util.Arrays;

public class Demo {
	
	public static void m1(int [] arr) {
		for(int i=0; i<arr.length; i++) {
			int count=1;
			if(arr[i]==-1) {
				continue;
			}
			
			for(int j=i+1; j< arr.length; j++) {
				if(arr[i]==arr[j]) {
					
						count++;
						arr[j]=-1;
					
					
					
				}
			}
			if(count>0 ) {
				System.out.println(arr[i]+ ": "+ count);
			}
		}
	}
	
	public static void main(String[] args) {
		int [] array= {2,3,5,6,7,3,2,2,5};
		int [] array1=new int[array.length];
		for(int i=0; i< array.length; i++) {
			array1[i]=array[i];
		}
		
	//	System.out.println(Arrays.toString(array1));
		m1(array);
	}

}
