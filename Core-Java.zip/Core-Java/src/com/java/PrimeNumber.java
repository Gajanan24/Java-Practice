package com.java;

public class PrimeNumber {
   public static void m1(int num) {
	   int m=num/2;
	   
	   int flag=0;
	   
	if (num==0 || num==1) {
		   System.out.println("Number is not prime number");
	}
	else {
		  for(int i=2; i<m; i++) {
			  if(num%i==0) {
				  System.out.println("Num is not prime");
				   flag=1;
				   break;
			  }
		  }
		  if(flag==0) {
			  System.out.println("Num is prime");
		  }
	   }
   }
   public static void main(String[] args) {
	m1(21);
}
}
