package com.java;

public class Palindrome {

	public static String reverseString(String s) {
		if (s.isEmpty()) // checks the string if empty
			return s;
		return reverseString(s.substring(1)) + s.charAt(0); // recursively called function
	}
	

	public static void check(String s) {
		String reverString = "";
		for (int i = s.length() - 1; i >= 0; i--) {
			reverString = reverString + s.charAt(i);
		}
		if (s.toLowerCase().equals(reverString.toLowerCase())) {
			System.out.println(s + " is palindrome String");
		} else {
			System.out.println(s + " is not palindrome string");
		}
	}

	public static void main(String[] args) {
		check("Abas");
		System.out.println(reverseString("This is Gajanan"));
	}

}
