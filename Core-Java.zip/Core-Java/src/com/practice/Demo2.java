package com.practice;

public class Demo2 {
	
	private String s;
	

	
	
  
	
	public static void main(String[] args) {
	  String string="Gajanan";
	  
	  string.length();
	}

}
