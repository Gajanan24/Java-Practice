package com.practice;

public class Student {
	
	public static void countOccurrences(String inputString, char c) {
	    int count = 0;
	    
//	   char [] j=inputString.toCharArray();
//	   
//	   for(int i=0; i<j.length; i++) {
//		   if(j[i] ==c) {
//			   count++;
//		   }
//	   }
	   

	   for(int i=0; i< inputString.length(); i++) {
		   if(inputString.charAt(i) == c) {
			   count++;
		   }
	   }
	   System.out.println(count);
	}
	
	public static void getChar(int index) {
		
		String string="Gajananan";
		for(int i=0; i<string.length(); i++) {
			
		}
	char c=	string.charAt(index);
		System.out.println("The character at position " + index + " is " + c);
	      
	}
	
	
	
     
	
	public static void main(String[] args) {
		countOccurrences("Gajanan", 'a');
		getChar(1);
		
		String s="Gajanan";
		String s2="Gajanam";
	 int result= s.compareTo(s2);
	 System.out.println(result);
	 String str = new String("Geeks").intern();
	 int countc=0;
	   
	 
	 char [] array= s.toCharArray();
	   for(int i=0; i< array.length; i++) {
		   if(array[i]=='n') {
			   countc++;
		   }
	   }
	   System.out.println(countc +"Countc");
	   int v=0;
	   for(int i=0; i<s.length(); i++) {
		   if(s.charAt(i) == 'a')
		   v++;
	   }
	   System.out.println(v +"v");
	}
}
