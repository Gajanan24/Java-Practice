package com.collection;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

public class Stream {
	public static void main(String[] args) {
		List number = Arrays.asList(2,3,4,5);
		
   Iterator<Integer> itr=	number.iterator();
   
   while(itr.hasNext()) {
	 Integer integer=  itr.next();
	 System.out.println(integer);
   }
   
   
		
	}
      

}
