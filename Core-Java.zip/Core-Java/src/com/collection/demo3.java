package com.collection;

import java.util.ArrayList;
import java.util.List;

public class demo3 {
	
	 ArrayList<Character> list;
	
	public demo3() {
		list=new ArrayList<Character>();
		list.add('a');
		list.add('e');
		list.add('i');
		list.add('o');
		list.add('u');
		
	}
	public  boolean isVowel(char c) {
		for(int i=0; i<list.size(); i++) {
			if(list.get(i)==c) {
				return true;
			}
			{
				return false;
			}
			
			
		}
            return false;

	}
	public int countVowel(String s) {
		
		int count=0;
		for(int i=0; i< s.length(); i++) {
			char c=s.charAt(i);
		      if(isVowel(c)) {
		    	  count++;
		      }
		}
              return count;
		
	}
	public static void main(String[] args) {
		demo3 demo3=new demo3();
		
		System.out.println(demo3.countVowel("GajananShinde"));
		
//		String s="Gajanan";
//		int s1=s.length();
//		boolean check=false;
//		for(int i=0; i<s.length()/2; i++) {
//			if(s.charAt(i)== s.charAt(s1)-1) {
//				 check=true;
//			}
//			   
//		}
//		System.out.println(check);
	}
	
	
	

}
