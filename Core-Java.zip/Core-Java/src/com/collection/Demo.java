package com.collection;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Demo {
  public static void main(String[] args) {
	int [] array= {2,3,4,5,7,6};
	int sum=0;
	for(int i: array) {
		sum+=i;
		System.out.println(sum);
		
	}
	Scanner sc =new Scanner(System.in);
	System.out.println("Enter a limit: ");
	int l=sc.nextInt();
	
	for(int j=0; j<l; j++) {
		 int k=1;
		 
	    int m=j+k;
	    
	     j=m;
	   System.out.println(j); 
		
	}
	
	
	
	
	
	
	
}
}
