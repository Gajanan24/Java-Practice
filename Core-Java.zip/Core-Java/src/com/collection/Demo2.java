package com.collection;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

public class Demo2 {
	public static void main(String[] args) {
		Map map=new HashMap();
		map.put(1, 123);
		map.put(2, 434);
		
		
		System.out.println(map);
		
		LinkedList<String> al=new LinkedList<String>();    
		al.add("Ravi");  
		al.add("Vijay");  
		al.add("Ravi");  
		al.add("Ajay");  
		System.out.println(al.get(0));
		
		
		
	}

}

