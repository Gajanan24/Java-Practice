package com.array;

import java.util.HashSet;
import java.util.Set;

public class Demo4 {
	

	
	public static void m2(int [] array) {
		int smallest=array[0];
		int largest=array[0];
		
		for(int i=0; i< array.length; i++) {
			
			if(array[i]< array[0]) {
				smallest=array[i];
			}
			if(array[i] > array[0]) {
				largest=array[i];
			}
			
		}
		System.out.println("smallest: " + smallest);
		System.out.println("smallest: " + largest);
		
	}
	
	public static void m1(int [] array) {
		Set set=new HashSet();
		for(int i: array) {
			set.add(i);
		}
		for(int i:array) {
			System.out.println(i);
		}
		System.out.println(set);
	}
   public static void main(String[] args) {
	 int [] array= {1,2,2,1,1};
	 m1(array);
	 boolean found=true;
	 for(int i=0; i<array.length/2; i++) {
         if(array[i]!=array[array.length-1-i]) {
        	 found=false;
         }
		 
	 }
	 System.out.println(found );
	 m2(array);
   
	 
}
}
