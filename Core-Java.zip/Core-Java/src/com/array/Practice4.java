package com.array;

public class Practice4 {
	public static void main(String[] args) {
		int [] array= {10, 12, 20, 30, 25, 40, 32, 31, 35, 50, 60};
		int []array1=new int[6];
		int j=0;
		for(int i=3; i< array.length-2; i++) {

			array1[j]=array[i];
			j++;
		}
		for(int i: array1) {
			System.out.println(i);
		}
	}

}
