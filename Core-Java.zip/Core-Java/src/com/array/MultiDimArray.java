package com.array;

import java.util.HashSet;
import java.util.Set;

public class MultiDimArray {
	
	
   	Set set=new HashSet();
	 
	public static void d(int [] array1) {
		Set<Integer> set=new HashSet();
		
		for(int i=0; i<array1.length; i++) {
			set.add(array1[i]);
		}
		System.out.println("set:  "+set);
		
	}
	
	
	
	
	
	
	public static void main(String[] args) {
		
		
	   
		int [] arr= {2,2,5,4,4,3,4,5};
	   d(arr);
		int[][] array= {
				{1,3,4},
				{2,4,3}
				
		};
		
		
		
		for(int i=0; i<array.length; i++)
		{
			for(int j=0; j<array[i].length; j++) {
				System.out.println(array[i][j]);
			}
		}
		System.out.println("length"+array[1].length);
		
	}

}
