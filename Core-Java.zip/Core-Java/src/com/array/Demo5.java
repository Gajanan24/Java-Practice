package com.array;

public class Demo5 {
	
	public static void main(String[] args) {
		int [] array= {2,5,75,8,67};
		for(int i=0; i< array.length; i++) {
			
			System.out.println(array[i]);
			
			if(array[i]==8) {
				break;
			}
			
		}
		
	}

}
