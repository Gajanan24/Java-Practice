package com.array;

public class Demo {
	public static void main(String[] args) {
		
	int count=0;
	int coun=0;
	int occ=-1;
	int bocc=-1;
	
	String s= "Gajanan Shinaade";
	for(int i=0; i<s.length(); i++) {
		if(s.charAt(i)=='G') {
			occ=i;
		}
	}
	
	for(int i=s.length()-1; i>=0; i++) {
		if(s.charAt(i)=='G') {
			bocc=i;
		}
	}
	System.out.println(bocc);

	System.out.println("occurence "+occ);
	
	System.out.println(s.contains("g"));
     char[] array=	s.toCharArray();
     for(int i=0; i<array.length; i++) {
    	 if(array[i]=='a') {
    		 coun++;
    	 }
     }
     System.out.println(coun);
     
	for(int i=0; i< s.length(); i++) {
		if(s.charAt(i) == 'a') {
			
			count++;
			
		}
	}
	System.out.println(count);
    
	
	
 
}
}
