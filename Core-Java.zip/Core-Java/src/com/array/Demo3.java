package com.array;

import java.util.ArrayList;
import java.util.List;

public class Demo3 {

	List list;

	public Demo3() {
		// TODO Auto-generated constructor stub

		list = new ArrayList();
		list.add("a");
		list.add("e");
		list.add("i");
		list.add("o");
		list.add("u");

	}

	public static void deleteV(String s) {
		String result = s.replaceAll("[aeiouAEIOU]", " ");
		System.out.println(result);
	}

	public static void main(String[] args) {
		deleteV("HeyHowareYou");
		String string="      A batman with bat";
	String s=string.replace("bat", "snow");
	System.out.println(s);
	String reversedString="";
	for(int i=string.length()-1; i>=0; i--) {
		reversedString+=string.charAt(i);
	}
	System.out.println(reversedString);
	System.out.println(string.startsWith("B"));
     String string2= string.trim();
	  System.out.println(string2);
	}
	
	

}
