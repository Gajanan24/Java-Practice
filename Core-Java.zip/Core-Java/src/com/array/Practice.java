package com.array;

import java.util.Scanner;

public class Practice {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
	int [] array= new int[10];
	int z=0;
	for(int i=0; i<array.length; i++) {
	 array[z]=sc.nextInt();
	 z++;
	}
	
	System.out.println("enter one number");
	int num=sc.nextInt();
	
	boolean found=false;
	for(int i=0; i<array.length; i++) {
		
	
		if(num==array[i]) {
			System.out.println("number is present in array" + num);
			found=true;
			break;
		}
		
	}
	if(!found) {
		System.out.println("no such number is present");
		
	}
	
	
	
	
	

}
}
