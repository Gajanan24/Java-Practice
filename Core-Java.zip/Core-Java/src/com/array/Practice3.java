package com.array;

import java.util.HashSet;
import java.util.Set;

public class Practice3 {
	public static void main(String[] args) {
		
	
	int [] array= {1,2,3,4,5,3,4,0};
	
	int [] arr1 = new int[array.length/2];
	
	for(int i=0; i<array.length-4; i++) {
		arr1[i]=array[i];
	}
	for(int i:arr1) {
		System.out.println(i);
	}
	
	
	
	
	
	int j=array.length-1;
	boolean b=true;
	for(int i=0; i<array.length/2; i++) {
		if(array[i]!=array[j]) {
			b=false;
			break;
		}
		else {
			j--;
		}
		
	}
	System.out.println(b);
	
	
	
	int largest=array[0];
	int smallest=array[0];
	for(int i: array) {
		if(array[i]>largest) {
			largest=array[i];
		}
		if(array[i]< smallest) {
			smallest=array[i];
		}
	}
	System.out.println("larest no: "+ largest + "smallest: " + smallest);
	int sum=0;
	
	for(int i: array) {
		sum+=i;
	}
	System.out.println("sum of all elements:" + sum);
	
	for(int i=array.length-1; i>=0; i--) {
		System.out.println(array[i]);
	}
    
	Set set=new HashSet();
	
	for(int i=0;i < array.length; i++) {
		set.add(array[i]);
	}
	
	System.out.println(set);
	
	
	
	}
}
	
