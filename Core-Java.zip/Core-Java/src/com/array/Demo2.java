package com.array;

public class Demo2 {
  public static void main(String[] args) {
	  String s= "Gajanan Shinaade";
		int occ=-1;
		for(int i=0; i<s.length(); i++) {
			if(s.charAt(i)=='n') {
				occ=i;
				break;
			}
		}
		System.out.println("occurence "+occ);
		
		
		int bocc=-1;;
		for(int i=s.length()-1; i>=0; i--) {
			if(s.charAt(i)=='G') {
				bocc=i;
				break;
			}
		}
		System.out.println(bocc);

		
}
}
