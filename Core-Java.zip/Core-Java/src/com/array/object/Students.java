package com.array.object;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Students {
	Integer rollno;
	Integer height;
	public Students() {
		super();
	}
	public Students(Integer rollno, Integer height) {
		super();
		this.rollno = rollno;
		this.height = height;
	}
	public Integer getRollno() {
		return rollno;
	}
	public void setRollno(Integer rollno) {
		this.rollno = rollno;
	}
	public Integer getHeight() {
		return height;
	}
	public void setHeight(Integer height) {
		this.height = height;
	}
	
	
}
