package com.array.object;

public class StudentDriver {
	
      static Student [] array =new Student[8];
      public static  void findAvg(Integer rollno) {
      for(Student student: array) {
    	  
    	  if(student!= null &&student.getRollNo().equals(rollno) ) {
    		  
    		  Integer sum=student.getSub1Marks()+student.getSub2Marks()+student.getSub3Marks();
    		  
    		  System.out.println("Roll no: " +student.getRollNo()+" " + "Avg Marks: " + sum/3);
    		  return;
    	  }
    	  
      }
      System.out.println("No student with roll no " + rollno + " found.");
     
      }
      
      public static void main(String[] args) {
		array[0]=new Student(12, 60, 76, 56);
		array[1]=new Student(11, 67, 86, 66);
		
		findAvg(12);
		findAvg(11);
		findAvg(1);
		
	}
     

}
