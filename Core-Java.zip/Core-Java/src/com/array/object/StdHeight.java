package com.array.object;

import java.time.chrono.HijrahChronology;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.swing.plaf.synth.SynthScrollPaneUI;

public class StdHeight {
	static List<Students> list=new ArrayList<Students>();
	
	
	
	public void calAvgHeight() {
		int sum=0;
		
		for( Students std: list) {
			
		 sum+= std.getHeight();
			
		}
		
	 int avgHeight=	sum/list.size();
	 System.out.println(avgHeight);
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter number of students");
		int numStudent=sc.nextInt();
		
        int [] height=new int[numStudent];
        
        for(int i=0; i<height.length; i++) {
        	System.out.println("Enter height of students in cm");
        	height[i]=sc.nextInt();
        }
        int sum=0;
        
        for(int i: height) {
        	sum+=i;
        }
        int avg=sum/numStudent;
        
        System.out.println(avg);
        
        
        	
        
        
		
	}
	

}
