package com.array.object;

public class EmployeeDriver {
	static Employee [] array=new Employee[10];
	
	public static Employee searchByName(String name) {
		for(Employee employee: array) {
			if(employee.getName()==name) {
				return employee;
			}
			else {
				return null;
			}
		}
		return null;
		
	}
	
	public static void main(String[] args) {
		
	
	
	Employee employee=new Employee();
	
  
	
	array[0]=new Employee("Abc", 1200.0, "12-09-2022");
	array[1]=new Employee("Bcc", 3200.0, "12-09-2022");
	
	for(Object obj: array) {
		//System.out.println(obj);
	}
	  System.out.println( searchByName("Abc"));
	
	
	
	}
}
