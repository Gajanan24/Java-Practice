package com.array.object;

public class Student {
	Integer rollNo;
	Integer sub1Marks;
	Integer sub2Marks;
	Integer sub3Marks;
	
	
	public Student() {
		super();
	}

	public Student(Integer rollNo, Integer sub1Marks, Integer sub2Marks, Integer sub3Marks) {
		super();
		this.rollNo = rollNo;
		this.sub1Marks = sub1Marks;
		this.sub2Marks = sub2Marks;
		this.sub3Marks = sub3Marks;
	}
	
	
	
	public Integer getRollNo() {
		return rollNo;
	}

	public void setRollNo(Integer rollNo) {
		this.rollNo = rollNo;
	}

	public Integer getSub1Marks() {
		return sub1Marks;
	}

	public void setSub1Marks(Integer sub1Marks) {
		this.sub1Marks = sub1Marks;
	}

	public Integer getSub2Marks() {
		return sub2Marks;
	}

	public void setSub2Marks(Integer sub2Marks) {
		this.sub2Marks = sub2Marks;
	}

	public Integer getSub3Marks() {
		return sub3Marks;
	}

	public void setSub3Marks(Integer sub3Marks) {
		this.sub3Marks = sub3Marks;
	}

	@Override
	public String toString() {
		return "Student [rollNo=" + rollNo + ", sub1Marks=" + sub1Marks + ", sub2Marks=" + sub2Marks + ", sub3Marks="
				+ sub3Marks + "]";
	}
	
	
	

}
