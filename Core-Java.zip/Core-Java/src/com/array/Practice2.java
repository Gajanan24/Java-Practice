package com.array;

import java.util.Scanner;

public class Practice2 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int [] array=new int[10];
		
		System.out.println("enter 10 numbers");
		
		for(int i=0; i< array.length; i++) {
			array[i]=	sc.nextInt();
		  
		}
		int nCount=0;
		int pCount=0;
		int oCount=0;
		int eCount=0;
		int zCount=0;
		
		for(int i: array) {
			if(i < 1) {
				nCount++;
			}
			else if(i>0) {
				pCount++;
			}
			else {
				zCount++;
			}
			 if(i%2== 0){
				eCount++;
			}
			else {
				oCount++;
			}
			
		}
		System.out.println(nCount);
		System.out.println(pCount);
		System.out.println("odd count:"+oCount);
		System.out.println(eCount);
		System.out.println(zCount);
		
		
			
	}

}
