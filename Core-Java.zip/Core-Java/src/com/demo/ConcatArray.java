package com.demo;

import java.util.Arrays;

public class ConcatArray {
	
	public static void main(String[] args) {
		int []array1= {1,2,4,5};
		int [] array2= {4,5,6};
		
		
		System.out.println(Arrays.toString(array1));
		int largestNum=array1[0];
		
		for(int array1Num: array1) {
			if(array1Num>largestNum)
				largestNum=array1Num;
		}
		System.out.println("largest number of array1: "+ largestNum);
		
		
		int sum1=0;
		for(int num: array1) {
			sum1+=num;
		}
		System.out.println("sum of all elements in array1: "+sum1);
		
		
		
		int lengthArray1=array1.length;
		int avg=sum1/lengthArray1;
		System.out.println("avarage of array1: "+ avg);
		int lengthArray2=array2.length;
		
		int sum=lengthArray1+lengthArray2;
		
		int [] array3=new int[sum];
		int i=0;
		for(int element: array1) {
			array3[i]=element;
			i++;
		}
		
		for(int j: array3) {
			System.out.println(j);
		}
		System.out.println("-------------");
		int z=2;
		for(int ele: array2) {
			array3[z]=ele;
			z++;
		}
		for(int a=0; array3.length>a; a++) {
			System.out.println(array3[a]);
			
		}
		System.out.println("array2 lenth: "+array3.length);
		
	}

}
