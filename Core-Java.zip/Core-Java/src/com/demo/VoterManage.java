package com.demo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class VoterManage {
	
	
	
	static List<Voter>list=new ArrayList<Voter>();
	
	public static void check(String name) {
		
		boolean found=false;
		
		for(Voter voter: list) {
			if(voter.getName().equalsIgnoreCase(name)) {
				found=true;
				
				if(voter.getAge()>=18) {
					System.out.println("You are eligible for voting");
				}else {
					System.out.println("You are minor");
				}
			
			}
			
		
		}
		if(!found) {
			System.out.println("No voter found with name: " + name);
		}
	}
	public static void main(String[] args) {
               list.add(new Voter("ABC", 17));
               list.add(new Voter("XYZ", 19));
               
               check("weq");
               
         List<Integer> voters=     list.stream().filter(p -> p.age >18).map(p -> p.age).collect(Collectors.toList());
         System.out.println(voters);
         
         List names = Arrays.asList("Reflection","Collection","Stream");
         List result = (List) names.stream().filter(s->((String) s).startsWith("S")).collect(Collectors.toList());
	}

}
