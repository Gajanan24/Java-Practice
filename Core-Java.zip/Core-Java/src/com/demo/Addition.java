package com.demo;

public class Addition {
	static int a=7;
	static int b=8;
	int c;
	
	public static void main(String[] args) {
		int c=5;
		
		int d=a+b+c;
		System.out.println(d);
		
	}

}
