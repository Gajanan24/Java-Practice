package com.demo;

import java.util.ArrayList;
import java.util.HashMap;

public class Collection {
	
	public static void main(String[] args) {
		HashMap<Integer, String> hashMap=new HashMap<>();
		hashMap.put(1, "Abc");
		System.out.println(hashMap.values());
		
		 ArrayList<String> languages = new ArrayList<>();

		    // add elements to the ArrayList
		    languages.add("Java");
		    languages.add("Python");
		    languages.add("JavaScript");
           System.out.println(languages);
           
           
		    for(String lang: languages) {
		    	System.out.println(lang);
		    }
		   System.out.println("Iteration using lambda");
		    languages.forEach((e) ->  { System.out.println(e);
		    } 
		    );
		
	}

}
