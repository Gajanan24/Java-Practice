package com.democom.lambda;

public class Demo {
  public static void main(String[] args) {
	 Say objSay= (int a, int b) ->  a+b;
		 
	 ;
		
	  
	  System.out.println(objSay.add(2,5));
  }
}
