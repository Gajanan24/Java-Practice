package com.democom.lambda;

public interface Say {
	public int add(int a, int b);

}
