package com.democom.lambda;

public class Circle{

	public static void main(String[] args) {
		int width=10;
		
		Drawable drawable =() -> {
			
			
				System.out.println("draw shape: " + width);
				
			};
			drawable.draw();
			
			Drawable drawable2= new Drawable() {
				
				@Override
				public void draw() {
					// TODO Auto-generated method stub

					System.out.println("draw shape: " + width);
					
				}
			};
			
			
		
	}
		

}
