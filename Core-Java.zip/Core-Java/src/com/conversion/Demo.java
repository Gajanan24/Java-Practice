package com.conversion;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Demo {
   public static void main(String[] args) throws ParseException {
	String s="100";
	
	int i = Integer.parseInt(s);
	
	System.out.println(s+100);
	System.out.println(i+100);
	String s2="Hi";
	try {
		int  j = Integer.parseInt(s2);
	} catch (Exception e) {
		
	}
	
	
	
	  String sDate1="31/12/1998";  
	  Date date=new SimpleDateFormat("dd/MM/yyyy").parse(sDate1);
	  System.out.println(sDate1+"\t"+date);  
}
}
