package com.thread;

public class GFG extends Thread {
	public void run() {
		System.out.println("thread starts running");
	}
	public static void main(String[] args) {
		GFG gfg=new GFG();
		gfg.start();
	}

}
