package com.thread;

public class Demo implements Runnable{

	@Override
	public void run() {
		System.out.println("thread !!!!!!!  starts");
		
	}
	public static void main(String[] args) {
		Demo demo=new Demo();
		Thread thread=new Thread(demo);
		
		thread.start();
	}
	

}
