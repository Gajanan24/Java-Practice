package com.bubbleSort;

public class BubbleSortDemo {
	
	
	//method to sort the numbers
	public  static void m1(int [] array) {
		for(int i=0; i< array.length; i++) {
			int temp;
			
			for(int j=i+1; j< array.length; j++) {
				if(array[i]> array[j]) {
					temp=array[i];
					array[i]=array[j];
					array[j]=temp;
				}	
				
			}
		}
		for(int i=0; i< array.length; i++) {
			System.out.println(array[i]);
		}
	}
	public static void main(String[] args) {
		int [] array= {1,5,8,4,2};
		m1(array);
	}

}
