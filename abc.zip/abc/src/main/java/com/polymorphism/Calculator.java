package com.polymorphism;

public class Calculator {
	
	int a;
	int b;
	
	
	
	
	
	
	public int add(int a, int b) {
		return a+b;
		
	}
	public double add(double a, double b) {
		return a+b;
	}
	
	public int add(int a, int b, int c) {
		return a+b+c;
	}
   public static void main(String[] args) {
	
	   Calculator cal=new Calculator();
//	   cal.a=1;
//	   cal.b=2;
	   
	   cal.add(2,2);
	   System.out.println(cal.add(2,2));
	   System.out.println(cal.add(2,7,6));
	   
	   System.out.println(cal.add(2.2, 2.3));
	   
}
}
