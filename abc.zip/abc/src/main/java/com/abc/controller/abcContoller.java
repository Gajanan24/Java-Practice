package com.abc.controller;

import java.sql.Connection;

public class abcContoller {
	
	

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		abcContoller ac=new abcContoller();
		Encapsulation e=new Encapsulation();
		//abcContoller e1=new Encapsulation();
		
		System.out.println(e.age);
		
		e.name="QWErr";
		System.out.println(e.name);
		e.setAddress("Kuadidssdsd");
		//e.setAddress("   .  .  ");
		System.out.println(e.getAddress());
		
		Encapsulation en = new Encapsulation();
	
		
		
		
		

		
	}

}
