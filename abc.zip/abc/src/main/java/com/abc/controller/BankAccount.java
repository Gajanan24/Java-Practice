package com.abc.controller;

public class BankAccount {
	private String accountNumber;
	 private String address;
	private double balance;
	
	public BankAccount() {
		super();
	}
	public BankAccount(String accountNumber, double balance) {
		super();
		this.accountNumber = accountNumber;
		this.balance = balance;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) throws Exception {
		
		if(12 > accountNumber.length()) {
			throw new Exception("Account no must be 12 digits");
			
		}
		this.accountNumber = accountNumber;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public void deposite(String amount) {
		 amount+= balance;
	}
	
	public void withdraw(double withdrawAmount) {
		balance-=withdrawAmount;
	}
	
	
		

}
