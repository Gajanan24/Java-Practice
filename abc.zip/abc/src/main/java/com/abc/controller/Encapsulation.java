package com.abc.controller;

public class Encapsulation {
	 int age;
	String name;
	private String address;
	
	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) throws Exception {
		if(9 > address.length()) {
			throw new Exception("address should 9 char only");
		}
		
		
		this.address = address;
	}


     public static void main (String[]args){
		
		Encapsulation en=new Encapsulation();
		en.age=10;
		en.address="abc";
		
		System.out.println(en.age);
		System.out.println(en.address);
		
		
		
	}
	

}
