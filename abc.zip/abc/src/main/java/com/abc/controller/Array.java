package com.abc.controller;

public class Array {

	public static void main(String[] args) {

		int[] num = { 2, 3, 4, 5, 6 };

		sum(num);

		Array a = new Array();
		// a.sum(num);
		
//		System.out.println(a.m1());
		
		int array[]=a.m1();
		for(int i=0; i<array.length; i++) {
			System.out.println(array[i]);
		}
		System.out.println("-------");
		for(int number:array) {
			System.out.println(number);
		}
		System.out.println(a.name());
	}

	public static void sum(int[] num) {

		int sum = 0;

		for (int i = 0; i < num.length; i++) {
			sum = sum + num[i];

//			System.out.println("Sum"+sum);
		}
		System.out.println("Sum: " + sum);

	}

	public int[] m1() {
		return new int[] { 1, 3, 4, 4 };

	}
	
	public String name() {
		return "Heyy !!!!";
	}

}
