package com.abc.controller;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class Demo {
  public static void main(String[] args) {
	List list=new ArrayList();
	list.add("Java");
	list.add(1);
	list.add("Python");
	list.add("Gajkajanan");
	
    Iterator iterator=	list.iterator();
    while(iterator.hasNext()) {
    	Object obj=  iterator.next();
    	System.out.println(obj);
    	
    }
	
	
	//System.out.println(list);
	
	List<String> list1=new ArrayList<String>();
	list1.add("Gajanan");
	System.out.println(list1);
	
	
	Set set=new HashSet();
	set.add(1);
	set.add(2);
	set.add(3);
	set.add(1);
	
	System.out.println(set + "set print");
	
	
	int [] bats= {1,10,4,27,6};
	System.out.println(bats);
	
	for(int i=0; i<bats.length; i++) {
		System.out.println(bats[i]);
	}
	
	int [] cats=new int[8];
	cats[1]=76;
	
	for(int i=0; i<cats.length; i++) {
		System.out.println(cats[i]);
	}
	
	for(int b: cats) {
		System.out.println(b);
	}
	
	Encapsulation1 en= new Encapsulation1();
	//en.setAge(1);
	//System.out.println("Age: "+en.getAge());
	
	//en.setAge(34);
//	en.age=-1;
//	System.out.println(en.age);
	en.setAge(100);
	System.out.println(en.getAge());
	//System.out.println(en.age);
	
	
	//System.out.println(en.getAge());
	
	String [] names={"Gajanan", "Prasad"};
	for(String name: names) {
		System.out.println(name);
		
		
		
	}
	int [] arr = new int[5];
	System.out.println(arr[4]=9);
	
	String [] n;
	
	
	
	
	
	
	
	
	
}
}
