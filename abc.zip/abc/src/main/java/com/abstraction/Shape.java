package com.abstraction;

public abstract class Shape {
	
	public abstract double getArea();
	public abstract double getPerimeter();
	public void name() {
		System.out.println("HO");
	}
	
	

}
