package com.abstraction;

public class Circle extends Shape{
	
	double redius;
	
	
//
//	public Circle() {
//		super();
//	}
	
	

	@Override
	public double getArea() {
		// TODO Auto-generated method stub
		return 3.14*(redius*redius);
	}

	public Circle(double redius) {
	super();
	this.redius = redius;
}

	@Override
	public double getPerimeter() {
		// TODO Auto-generated method stub
		return 2*3.14*redius;
	}
	

}
