package com.abstraction;

public class Rectangle extends Shape{
	
	 double width;
	 double length;
	 
//	 public void setWidth(double width) {
//		 this.width=width;
//	 }
//	 public double getWidth() {
//		 return width;
//	 }
	 
	 
	 
	 
	

	@Override
	public double getArea() {
		
		return width*length;
	}

	public double getLength() {
		return length;
	}

	public void setLength(double length) {
		this.length = length;
	}

	public double getWidth() {
		return width;
	}

	public void setWidth(double width) {
		this.width = width;
	}

	@Override
	public double getPerimeter() {
		// TODO Auto-generated method stub
		return 2*(width+length);
	}
	

}
