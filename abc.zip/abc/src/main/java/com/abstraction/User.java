package com.abstraction;

import java.util.Scanner;

import com.abc.controller.BankAccount;

public class User  {
	
	public static void main(String[] args) {
		Rectangle rect=new Rectangle();
//		rect.length=10.0;
//		rect.width=8.0;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Length");
		double l= sc.nextDouble();
		
		rect.length=l;
		
		
		
		
		System.out.println("Enter width");
		double w=sc.nextDouble();
		rect.width=w;
		
		System.out.println(rect.getArea());
		
		
		
		
		
		//Shape rectangle=new Rectangle();
		
		
		System.out.println("Area of Rectangle:  "+ rect.getArea());
		
		Shape circle =new Circle(1.1);
		
		System.out.println("Area of circle: "+circle.getArea());
		circle.name();
		BankAccount b=new BankAccount();
	   
		
		
		
		
		
		
	}

}
