package com.abstraction;

public interface Vehical {
	void start();
	void stop();
	

}
