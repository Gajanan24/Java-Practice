package com.demo;

public class Driver {
  public static void main(String[] args) {
	int arr[]= {1,4,55,49,7};
	Array a=new Array();
	int n=arr.length;
	System.out.println("Peak element in this Arrray is: "+ a.findPeak(arr, n));
    }
}
