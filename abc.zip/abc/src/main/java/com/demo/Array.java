package com.demo;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Array {

	static int findPeak(int[] arr, int n) {
		if (n == 1) {
			return 0;
		}
		if (arr[0] >= arr[1])
			return 0;
		if (arr[n - 1] >= arr[n - 2])
			return n - 1;
		for (int i = 1; i < n - 1; i++) {
			if (arr[i] >= arr[i - 1] && arr[i] >= arr[i + 1])
				return i;

		}
		return n;

	}

	public static void main(String[] args) {

		int[][] num = { { 1, 4, 6, 6 }, { 4, 7, 8 }, { 2, 3 } };
		for (int i = 0; i < num.length; i++) {
			for (int j = 0; j < num[i].length; j++) {
				System.out.println(num[i][j]);
			}

		}

		int[] numbers = { 3, 5, 8, 4, 4 };
		
		System.out.println("For each loop");
		for (int i : numbers) {
			System.out.println(i);
		}
		System.out.println("End of for each loop");

		List a = Arrays.asList(numbers);

		System.out.println("List: " + a);
//		for (int i : a) {
//			System.out.println(i);
//		}

		Map<Integer, String> names = new HashMap();
		names.put(1, "Gajanan");
		names.put(2, "Prasad");
		System.out.println(names.get(1));

		System.out.println(names.values());
		System.out.println(names.keySet());

		names.replace(1, "Gajanan Shinde");
		System.out.println(names.values());

		String[] geeks = { "Rahul", "Utkarsh", "Shubham", "Neelam" };

        // Conversion of array to ArrayList
        // using Arrays.asList
		List al = Arrays.asList(geeks);

		System.out.println(al);
		
		int [] rollno= {4,6,7,74};
		List rn=Arrays.asList(rollno);
		
		System.out.println(rn);
		
		int g=49;
		int a1=48;
		
		int array[]= {3,4,6,8,986,5};
		
		int [] array1=new int[10];
		array1[0]=1;
		
		
		//Multidaimentional Array
		
		int [][] lotteryNumbers= {
				{1,2,4,5,6},
				{10,20,40,50,60},
				{11,21,41,51,61},
				{12,22,42,52,62},
				{19,29,49,59,69}
		};
		
		for (int i = 0; i < lotteryNumbers.length; i++) {
			for (int j = 0; j < lotteryNumbers[i].length; j++) {
				
				System.out.print(lotteryNumbers[i][j]+ " "); 
				
			}
			System.out.println();
			
		}
		
		
		
		
		

	}

}
