package com.demo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.jboss.jandex.Main;

public class Practice {
	
	public static void main(String[] args) {
		
		
			try {
			int i=10/0;
			}
			catch(Exception e){
				System.out.println(e.getMessage());
			}
		
		
	
	
	Map<Integer, String> names=new HashMap();
	   names.put(1, "Amit");
	   names.put(2, "Anita");
	   
	  System.out.println( names.values());
	  
	  List number=new ArrayList<Integer>();
	  number.add(34);
	  number.add(54);
	  number.add(87);
	  
	  
	  
	  number.forEach(   (num) -> {
		  System.out.println(num);
	  });
	  
	  Iterator itr=  number.iterator();
	  
	  while(itr.hasNext()) {
		     System.out.println( itr.next());
		     
		     
	  }
	  System.out.println("Hiii");
	  
	  number.forEach( (n) -> { System.out.println(n); } );
	  
	  
	  
	  List<String> items = new ArrayList<>();

      items.add("coins");
      items.add("pens");
      items.add("keys");
      items.add("sheets");

//      items.forEach((String name) -> {
//          System.out.println(name);
//      });
      
   
      
	  items.forEach( (n) -> {
		  System.out.println(n);
	  }); 
	
	}
	
	

}
