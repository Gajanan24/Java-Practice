package com.demo.student;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;
import java.util.stream.Collectors;

import javax.swing.plaf.basic.BasicLookAndFeel;

import org.hibernate.boot.model.naming.CamelCaseToUnderscoresNamingStrategy;


public class Driver {
	
	
	
	public Driver() {
		//this.students=new ArrayList<>();
	}


    static List<Student> students=new ArrayList<>();
	
	
	public void addStudent(Integer id, String name, Double fee) {

		Student student = new Student(id,name, fee);

		students.add(student);

		}
	
	
	public Student searchById(Integer id) {

		for (Student student : students) {

		   if (student.getId() == id) {

		      System.out.println(student.getName());
			   return student;

		}
		   
			  

		}
		return null;
		}
	public Student searchByName(String name) {
		for(Student std: students) {
			if(std.getName()==name) {
				System.out.println(std.getFee());
				return std;
			}
		}
		return null;
	}
	
	public static void main(String[] args) {
		
		
//	Optional<Student> optionalStudent=	students.stream().max((s1,s2)->s1.getFee().compareTo(s2.getFee()));
	
//	
//	if(optionalStudent.isPresent()) {
//		Student std=optionalStudent.get();
//		
//		System.out.println(std+" is paying highest fee");
//	}
//	else {
//		System.out.println("No Student is present");
//	}
//	
//	Scanner scanner=new Scanner(System.in);
//	   int i=scanner.nextInt();
//	     for(int j=0; j <= i; j++) {
//	    	 
//	    	 Student student;
//	    	 System.out.println(student.getId());
//	    	 
//	     }
		

	  
	  
	    Driver drvDriver=new Driver();
	    drvDriver.addStudent(1, "Gajanam", 1200.0);
	    drvDriver.addStudent(2, "abc", 1000.0);
	    drvDriver.addStudent(3, "xyz", 800.0);
	    
	   drvDriver.searchById(2);
	   
	   drvDriver.searchByName("xyz");
	   
	   Collections.sort(students);
	   for(Student st: students) {
		   System.out.println( st.getId() +" " + st.getName() +" " + st.getFee() );
	   }
	   
	   
	   
	   System.out.println("comparator");
	   Collections.sort(students, new FeeComparator());
	   
	   for(Student st: students) {
		   System.out.println( st.getId() +" " + st.getName() +" " + st.getFee() );
	   }
	   
	     synchronized (students) {
		 Iterator<Student> itr=  students.iterator();
		 
		 while(itr.hasNext()) {
			 System.out.println(itr.next());
		 }
		
	     }
	     System.out.println("Array of student list");
	 Object[] arrayStd =  students.toArray();
	 for(Object student: arrayStd) {
		System.out.println(student);
	}
	 System.out.println("list of std");
	 List<Object> list=new ArrayList<>(Arrays.asList(arrayStd));
	 System.out.println(list);
	}
}
