package com.demo.student;

import java.util.Comparator;

public class FeeComparator implements Comparator<Student> {

	@Override
	public int compare(Student s1, Student s2) {
		if(s1.fee==s2.fee) {
			return 0;
		}
		else if(s1.fee> s2.fee) {
			return 1;
		}
		else
		return -1;
	}

}
